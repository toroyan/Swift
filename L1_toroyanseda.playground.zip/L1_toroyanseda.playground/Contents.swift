//: Playground - noun: a place where people can play

import UIKit

// task 1
var a:Double=3
var b:Double=6
var c:Double=3
var x1,x2:Double
var D:Double=pow(b,2)-4*a*c
print("D is:", D)
if(D>0){
    x1=(-b+sqrt(D))/2*a
    x2=(-b-sqrt(D))/2*a
    print("D>0 -> x1,x2 are:", x1,x2)
}
else if D==0{
    x1=(-b/(2*a))
    x2=x1;
    print("D=0 -> x1=x2:", x1)
    
}
else{
    print("There are no any x1,x2")
}


// task 2

var k1: Double=10 //катет а
var k2: Double=8 //катет
var h: Double=(pow(k1,2)+pow(k2,2)) // гипотенуза
var S:Double=(k1+k2)/2 //  площадь
var P:Double=k1+k2+h //периметр
print("Площадь: ", S,"\nГипотенуза: ", h, "\nПериметр: ", P)


//task 3
var A:Double=1000; // сумма вклада
let R:Double=12/100 // 12% - годовой процент
var S1:Int=Int(A*pow((1+R),5))
print("Ваш вклад через 5 лет составит:", S1)

